package com.alfy.music.ui

import android.app.Application
import android.content.ComponentName
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.alfy.music.data.AutoPlaylist
import com.alfy.music.data.Playlist
import com.alfy.music.data.PlaylistStore
import com.alfy.music.data.Prefs
import com.alfy.music.data.Song
import com.alfy.music.data.SongRepository
import com.alfy.music.service.MusicService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class Mode(val label: String) { LAGU("Lagu"), FOLDER("Folder"), ARTIS("Artis"), ALBUM("Album") }

class MainViewModel(private val app: Application) : AndroidViewModel(app) {
    private val prefs = Prefs(app)
    private val store = PlaylistStore(app)
    private var ctrl: MediaController? = null

    var playlists by mutableStateOf(store.load()); private set
    var openPlaylist by mutableStateOf<Long?>(null)

    private fun commit(l: List<Playlist>) { playlists = l; store.save(l) }
    private fun update(id: Long, f: (Playlist) -> Playlist) = commit(playlists.map { if (it.id == id) f(it) else it })

    fun createPlaylist(name: String) {
        val n = name.trim().ifEmpty { return }
        commit(playlists + Playlist((playlists.maxOfOrNull { it.id } ?: 0L) + 1, n))
    }
    fun renamePlaylist(id: Long, name: String) { val n = name.trim().ifEmpty { return }; update(id) { it.copy(name = n) } }
    fun deletePlaylist(id: Long) {
        playlists.firstOrNull { it.id == id }?.takeIf { it.auto }?.let { store.dismiss(it.key) }
        if (openPlaylist == id) openPlaylist = null
        commit(playlists.filter { it.id != id })
    }
    fun togglePin(id: Long) {
        val p = playlists.firstOrNull { it.id == id } ?: return
        val rest = playlists.filter { it.id != id }
        val at = if (!p.pinned) 0 else rest.count { it.pinned }
        commit(rest.toMutableList().apply { add(at, p.copy(pinned = !p.pinned)) })
    }
    fun movePlaylist(from: Int, to: Int) {
        val l = playlists
        if (from !in l.indices || to !in l.indices || l[from].pinned != l[to].pinned) return
        commit(l.toMutableList().apply { add(to, removeAt(from)) })
    }
    fun addSongs(id: Long, ids: Collection<Long>) = update(id) { p -> p.copy(songIds = p.songIds + ids.filter { it !in p.songIds }) }
    fun removeSong(id: Long, songId: Long) = update(id) { p -> p.copy(songIds = p.songIds - songId) }
    fun moveSong(id: Long, fromId: Long, toId: Long) = update(id) { p ->
        val a = p.songIds.indexOf(fromId); val b = p.songIds.indexOf(toId)
        if (a < 0 || b < 0) p else p.copy(songIds = p.songIds.toMutableList().apply { add(b, removeAt(a)) })
    }

    var songs by mutableStateOf<List<Song>>(emptyList()); private set
    var mode by mutableStateOf(Mode.LAGU); private set
    var group by mutableStateOf<String?>(null)
    var current by mutableStateOf<Song?>(null); private set
    var playing by mutableStateOf(false); private set
    var position by mutableLongStateOf(0L); private set
    var duration by mutableLongStateOf(0L); private set
    var shuffle by mutableStateOf(false); private set
    var repeat by mutableStateOf(Player.REPEAT_MODE_OFF); private set
    var bgUri by mutableStateOf(prefs.bg); private set

    private val listener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) = sync(player)
    }

    init {
        val token = SessionToken(app, ComponentName(app, MusicService::class.java))
        val f = MediaController.Builder(app, token).buildAsync()
        f.addListener({
            try { ctrl = f.get().also { it.addListener(listener); sync(it) } } catch (_: Exception) {}
        }, ContextCompat.getMainExecutor(app))
        viewModelScope.launch {
            while (true) {
                delay(500)
                ctrl?.takeIf { it.isPlaying }?.let {
                    position = it.currentPosition
                    duration = it.duration.coerceAtLeast(0)
                }
            }
        }
    }

    private fun sync(p: Player) {
        playing = p.isPlaying
        shuffle = p.shuffleModeEnabled
        repeat = p.repeatMode
        position = p.currentPosition
        duration = p.duration.coerceAtLeast(0)
        val id = p.currentMediaItem?.mediaId
        current = if (id == null) null else songs.firstOrNull { it.id.toString() == id }
    }

    fun load() {
        viewModelScope.launch {
            songs = withContext(Dispatchers.IO) { SongRepository.query(app) }
            if (songs.isNotEmpty()) {
                val all = songs.map { it.id }.toHashSet()
                val merged = withContext(Dispatchers.Default) {
                    AutoPlaylist.merge(playlists, songs, store.dismissed())
                        .map { p -> p.copy(songIds = p.songIds.filter { it in all }) }
                }
                commit(merged)
            }
            ctrl?.let(::sync)
        }
    }

    fun updateMode(m: Mode) { mode = m; group = null }

    private fun keyOf(s: Song) = when (mode) {
        Mode.FOLDER -> s.folder
        Mode.ARTIS -> s.artist
        Mode.ALBUM -> s.album
        Mode.LAGU -> ""
    }

    val shown: List<Song>
        get() = if (mode == Mode.LAGU) songs else songs.filter { keyOf(it) == group }

    val groups: List<Pair<String, Int>>
        get() = songs.groupBy { keyOf(it) }.map { it.key to it.value.size }.sortedBy { it.first.lowercase() }

    private fun item(s: Song) = MediaItem.Builder()
        .setMediaId(s.id.toString())
        .setUri(s.uri)
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(s.title).setArtist(s.artist).setAlbumTitle(s.album)
                .setArtworkUri(Uri.parse("content://media/external/audio/media/${s.id}/albumart"))
                .build()
        ).build()

    fun play(song: Song, from: List<Song>? = null) {
        val c = ctrl ?: return
        val list = from ?: shown.ifEmpty { songs }
        c.setMediaItems(list.map(::item), list.indexOf(song).coerceAtLeast(0), 0L)
        c.prepare(); c.play()
    }

    fun toggle() {
        val c = ctrl ?: return
        if (c.mediaItemCount == 0) { songs.firstOrNull()?.let(::play); return }
        if (c.isPlaying) c.pause() else c.play()
    }
    fun next() { ctrl?.seekToNext() }
    fun prev() { ctrl?.seekToPrevious() }
    fun seekTo(ms: Long) { ctrl?.seekTo(ms); position = ms }
    fun toggleShuffle() { ctrl?.let { it.shuffleModeEnabled = !it.shuffleModeEnabled } }
    fun cycleRepeat() {
        ctrl?.let {
            it.repeatMode = when (it.repeatMode) {
                Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                else -> Player.REPEAT_MODE_OFF
            }
        }
    }
    fun setBg(u: Uri?) { prefs.bg = u; bgUri = u }

    override fun onCleared() { ctrl?.release(); super.onCleared() }
}
