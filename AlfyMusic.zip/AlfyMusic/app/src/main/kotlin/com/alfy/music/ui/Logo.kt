package com.alfy.music.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.alfy.music.data.Prefs
import kotlinx.coroutines.delay

private val Rainbow = listOf(
    Color(0xFFFF3B30), Color(0xFFFF9500), Color(0xFFFFE600), Color(0xFF34C759),
    Color(0xFF00C7FF), Color(0xFF5856FF), Color(0xFFAF52DE), Color(0xFFFF3B30)
)

/** State logo (nama + kecepatan pelangi), tersimpan di Prefs. */
object LogoState {
    var name by mutableStateOf("AlfyMusic"); private set
    var speed by mutableFloatStateOf(1f); private set
    private var prefs: Prefs? = null

    fun init(ctx: android.content.Context) {
        if (prefs != null) return
        prefs = Prefs(ctx.applicationContext).also { name = it.appName; speed = it.rainbowSpeed }
    }
    fun updateName(n: String) { val v = n.trim().ifEmpty { return }; name = v; prefs?.appName = v }
    fun updateSpeed(s: Float) { speed = s.coerceIn(0f, 5f); prefs?.rainbowSpeed = speed }
}


/** True saat UI terlihat (ON_START..ON_STOP). Saat false semua animasi UI dihentikan; ExoPlayer/service tidak terpengaruh. */
object AppForeground { var active by mutableStateOf(true) }

/** Fase animasi pelangi bersama (kecepatan dari LogoState.speed = Slider Pengaturan). Dipakai logo & drawer. */
@Composable
fun rememberRainbowPhase(): State<Float> {
    val phase = remember { mutableFloatStateOf(0f) }
    val active = AppForeground.active
    LaunchedEffect(active) {
        if (!active) return@LaunchedEffect
        var last = 0L
        while (true) {
            val sp = LogoState.speed
            if (sp <= 0f) { last = 0L; delay(200); continue }
            androidx.compose.runtime.withFrameNanos { n ->
                if (last != 0L) phase.floatValue = (phase.floatValue + (n - last) / 1e9f * sp * 100f) % 400f
                last = n
            }
        }
    }
    return phase
}

/** Teks pelangi beranimasi, kecepatan identik dengan AlfyLogo. */
@Composable
fun RainbowText(text: String, modifier: Modifier = Modifier, fontSize: androidx.compose.ui.unit.TextUnit = 22.sp) {
    val phase by rememberRainbowPhase()
    Text(
        text, modifier, maxLines = 1,
        style = TextStyle(
            brush = Brush.linearGradient(
                Rainbow, start = Offset(phase, 0f), end = Offset(phase + 400f, 0f), tileMode = TileMode.Repeated
            ),
            fontSize = fontSize, fontWeight = FontWeight.ExtraBold, letterSpacing = 0.5.sp
        )
    )
}

/** Logo vertikal: ikon not di atas, teks pelangi di bawah. Klik = ganti nama. */
@Composable
fun AlfyLogo(modifier: Modifier = Modifier, onClick: () -> Unit = {}) {
    val phase by rememberRainbowPhase()
    fun brush() = Brush.linearGradient(
        Rainbow, start = Offset(phase, 0f), end = Offset(phase + 400f, 0f), tileMode = TileMode.Repeated
    )
    Column(
        modifier.clip(RoundedCornerShape(8.dp)).clickable(onClick = onClick).padding(horizontal = 6.dp, vertical = 2.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(
            Ic.Note, null,
            Modifier.size(22.dp)
                .graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
                .drawWithCache {
                    onDrawWithContent { drawContent(); drawRect(brush(), blendMode = BlendMode.SrcIn) }
                },
            tint = Color.Black
        )
        Text(
            LogoState.name, maxLines = 1,
            style = TextStyle(brush = brush(), fontSize = 13.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 0.5.sp)
        )
    }
}

@Composable
fun RenameAppDialog(onDismiss: () -> Unit) {
    var text by remember { mutableStateOf(LogoState.name) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Ganti Nama Aplikasi") },
        text = { OutlinedTextField(text, { text = it }, singleLine = true, label = { Text("Nama aplikasi") }) },
        confirmButton = {
            TextButton({ LogoState.updateName(text); onDismiss() }, enabled = text.isNotBlank()) { Text("Simpan") }
        },
        dismissButton = { TextButton(onDismiss) { Text("Batal") } }
    )
}
