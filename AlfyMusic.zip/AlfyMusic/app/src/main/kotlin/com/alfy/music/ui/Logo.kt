package com.alfy.music.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Rainbow = listOf(
    Color(0xFFFF3B30), Color(0xFFFF9500), Color(0xFFFFE600), Color(0xFF34C759),
    Color(0xFF00C7FF), Color(0xFF5856FF), Color(0xFFAF52DE), Color(0xFFFF3B30)
)

/** Logo AlfyMusic: ikon not + teks, gradien pelangi beranimasi. Ringkas agar tidak menutupi daftar lagu. */
@Composable
fun AlfyLogo(modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "rainbow")
    val shift by t.animateFloat(
        0f, 400f, infiniteRepeatable(tween(4000, easing = LinearEasing), RepeatMode.Restart), label = "shift"
    )
    fun brush() = Brush.linearGradient(
        Rainbow, start = Offset(shift, 0f), end = Offset(shift + 400f, 0f), tileMode = TileMode.Repeated
    )
    Column(modifier.fillMaxWidth().padding(top = 4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(
            Ic.Note, null,
            Modifier.size(28.dp)
                .graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
                .drawWithCache {
                    val b = brush()
                    onDrawWithContent { drawContent(); drawRect(b, blendMode = BlendMode.SrcIn) }
                },
            tint = Color.Black
        )
        Text(
            "AlfyMusic",
            style = TextStyle(brush = brush(), fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.sp)
        )
    }
}
