package com.alfy.music.data

import android.content.ContentUris
import android.content.Context
import android.provider.MediaStore.Audio.Media as M

object SongRepository {
    fun query(ctx: Context): List<Song> {
        val out = ArrayList<Song>()
        val base = M.EXTERNAL_CONTENT_URI
        val proj = arrayOf(M._ID, M.TITLE, M.ARTIST, M.ALBUM, M.DURATION, M.DATA)
        ctx.contentResolver.query(base, proj, "${M.DURATION}>0", null, "${M.TITLE} COLLATE NOCASE ASC")?.use { c ->
            while (c.moveToNext()) {
                val id = c.getLong(0)
                out += Song(
                    id = id,
                    title = c.getString(1) ?: "Tanpa judul",
                    artist = c.getString(2)?.takeIf { it != "<unknown>" } ?: "Artis tidak diketahui",
                    album = c.getString(3) ?: "Album tidak diketahui",
                    folder = c.getString(5)?.substringBeforeLast('/')?.substringAfterLast('/') ?: "-",
                    durationMs = c.getLong(4),
                    uri = ContentUris.withAppendedId(base, id)
                )
            }
        }
        return out
    }
}
