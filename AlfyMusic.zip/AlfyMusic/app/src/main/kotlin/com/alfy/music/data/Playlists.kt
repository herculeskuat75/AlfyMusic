package com.alfy.music.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Playlist(
    val id: Long,
    val name: String,
    val pinned: Boolean = false,
    val auto: Boolean = false,
    val key: String = "",
    val songIds: List<Long> = emptyList()
)

/** Penyimpanan playlist (nama, urutan, pin, urutan lagu) di SharedPreferences sebagai JSON. */
class PlaylistStore(ctx: Context) {
    private val sp = ctx.getSharedPreferences("alfy_playlists", Context.MODE_PRIVATE)

    fun load(): List<Playlist> = try {
        val arr = JSONArray(sp.getString("list", "[]"))
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            val ids = o.getJSONArray("songs")
            Playlist(
                id = o.getLong("id"), name = o.getString("name"),
                pinned = o.optBoolean("pinned"), auto = o.optBoolean("auto"),
                key = o.optString("key"),
                songIds = (0 until ids.length()).map { ids.getLong(it) }
            )
        }
    } catch (_: Exception) { emptyList() }

    fun save(list: List<Playlist>) {
        val arr = JSONArray()
        list.forEach { p ->
            arr.put(JSONObject().put("id", p.id).put("name", p.name).put("pinned", p.pinned)
                .put("auto", p.auto).put("key", p.key).put("songs", JSONArray(p.songIds)))
        }
        sp.edit().putString("list", arr.toString()).apply()
    }

    fun dismissed(): Set<String> = sp.getStringSet("dismissed", emptySet()) ?: emptySet()
    fun dismiss(key: String) {
        if (key.isNotEmpty()) sp.edit().putStringSet("dismissed", dismissed() + key).apply()
    }
}

/** Auto-playlist: ekstraksi kata kunci paling sering dari judul (+artis), tanpa library fuzzy. */
object AutoPlaylist {
    private val stop = setOf(
        "the", "and", "feat", "ft", "featuring", "with", "from", "for", "you", "your", "official", "video",
        "audio", "lyrics", "lyric", "music", "remix", "version", "live", "mp3", "hd", "full", "album",
        "song", "new", "original", "mix", "edit", "radio", "dan", "yang", "untuk", "dari", "www", "com",
        "youtube", "download", "free", "track", "cover", "acoustic", "instrumental", "visualizer", "unknown"
    )
    private val word = Regex("[\\p{L}\\p{N}]+")

    private fun tokens(s: Song): Set<String> {
        val text = if (s.artist.startsWith("Artis tidak")) s.title else s.title + " " + s.artist
        return word.findAll(text.lowercase()).map { it.value }
            .filter { it.length >= 3 && !it.all(Char::isDigit) && it !in stop }.toSet()
    }

    private fun pretty(k: String) = k.replaceFirstChar { it.uppercase() }

    /** Gabungkan hasil deteksi ke daftar playlist yang ada. Lagu BENAR-BENAR dimasukkan. */
    fun merge(existing: List<Playlist>, songs: List<Song>, dismissed: Set<String>, minCount: Int = 3, maxLists: Int = 10): List<Playlist> {
        if (songs.isEmpty()) return existing
        val index = HashMap<String, MutableList<Long>>()
        songs.forEach { s -> tokens(s).forEach { index.getOrPut(it) { ArrayList() }.add(s.id) } }
        val cap = if (songs.size >= 10) songs.size * 0.6 else Double.MAX_VALUE
        val chosen = ArrayList<Pair<String, List<Long>>>()
        index.entries.filter { it.value.size >= minCount && it.value.size <= cap }
            .sortedWith(compareByDescending<Map.Entry<String, MutableList<Long>>> { it.value.size }.thenBy { it.key })
            .forEach { (k, ids) ->
                if (chosen.size >= maxLists) return@forEach
                val set = ids.toHashSet()
                val redundant = chosen.any { (_, c) -> set.count { it in c.toHashSet() } >= 0.8 * set.size }
                if (!redundant) chosen += k to ids
            }
        val out = existing.toMutableList()
        var nextId = (out.maxOfOrNull { it.id } ?: 0L) + 1
        for ((k, ids) in chosen) {
            val i = out.indexOfFirst { it.auto && it.key == k }
            if (i >= 0) {
                val p = out[i]
                val missing = ids.filter { it !in p.songIds }
                if (missing.isNotEmpty()) out[i] = p.copy(songIds = p.songIds + missing)
            } else if (k !in dismissed) {
                out += Playlist(nextId++, pretty(k), auto = true, key = k, songIds = ids)
            }
        }
        return out
    }
}
