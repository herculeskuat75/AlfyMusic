package com.alfy.music.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalViewConfiguration
import androidx.compose.ui.platform.ViewConfiguration
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.alfy.music.data.Playlist
import sh.calvin.reorderable.ReorderableItem
import sh.calvin.reorderable.rememberReorderableLazyListState

private val W = Color.White
private val W70 = Color(0xB3FFFFFF)

/** Tekan lama = 0,5 detik untuk mulai drag. */
@Composable
private fun LongPress1s(content: @Composable () -> Unit) {
    val base = LocalViewConfiguration.current
    val vc = remember(base) {
        object : ViewConfiguration by base { override val longPressTimeoutMillis: Long get() = 500L }
    }
    CompositionLocalProvider(LocalViewConfiguration provides vc, content = content)
}

sealed interface Dlg {
    object Create : Dlg
    class Rename(val p: Playlist) : Dlg
    class Delete(val p: Playlist) : Dlg
}

@Composable
fun PlaylistDialogs(vm: MainViewModel, dlg: Dlg?, onDismiss: () -> Unit) {
    when (dlg) {
        null -> {}
        is Dlg.Delete -> AlertDialog(
            onDismissRequest = onDismiss,
            title = { Text("Hapus playlist?") },
            text = { Text("\"${dlg.p.name}\" akan dihapus (lagu tidak dihapus dari perangkat).") },
            confirmButton = { TextButton({ vm.deletePlaylist(dlg.p.id); onDismiss() }) { Text("Hapus") } },
            dismissButton = { TextButton(onDismiss) { Text("Batal") } }
        )
        else -> {
            val rename = dlg as? Dlg.Rename
            var text by remember { mutableStateOf(rename?.p?.name ?: "") }
            AlertDialog(
                onDismissRequest = onDismiss,
                title = { Text(if (rename != null) "Ganti nama playlist" else "Buat playlist baru") },
                text = { OutlinedTextField(text, { text = it }, singleLine = true, label = { Text("Nama playlist") }) },
                confirmButton = {
                    TextButton({
                        if (rename != null) vm.renamePlaylist(rename.p.id, text) else vm.createPlaylist(text)
                        onDismiss()
                    }, enabled = text.isNotBlank()) { Text("Simpan") }
                },
                dismissButton = { TextButton(onDismiss) { Text("Batal") } }
            )
        }
    }
}

@Composable
fun ColumnScope.DrawerContent(
    vm: MainViewModel,
    onSettings: () -> Unit,
    onBackground: () -> Unit,
    onOpenPlaylist: (Long) -> Unit
) {
    var dlg by remember { mutableStateOf<Dlg?>(null) }
    RainbowText(LogoState.name, Modifier.padding(24.dp), fontSize = 24.sp)
    NavigationDrawerItem(label = { Text("Pengaturan") }, selected = false, onClick = onSettings,
        modifier = Modifier.padding(horizontal = 12.dp))
    NavigationDrawerItem(label = { Text("Ganti Latar Belakang") }, selected = false, onClick = onBackground,
        modifier = Modifier.padding(horizontal = 12.dp))
    NavigationDrawerItem(label = { Text("+ Buat Playlist Baru") }, selected = false,
        onClick = { dlg = Dlg.Create }, modifier = Modifier.padding(horizontal = 12.dp))
    Text("Daftar Playlist", Modifier.padding(28.dp, 16.dp, 16.dp, 4.dp), color = W70, fontSize = 13.sp,
        fontWeight = FontWeight.SemiBold)
    Text("Tekan lama 0,5 detik lalu geser untuk mengurutkan", Modifier.padding(28.dp, 0.dp, 16.dp, 4.dp),
        color = Color(0x80FFFFFF), fontSize = 11.sp)

    val listState = rememberLazyListState()
    val rs = rememberReorderableLazyListState(listState) { from, to -> vm.movePlaylist(from.index, to.index) }
    LongPress1s {
        LazyColumn(Modifier.weight(1f, fill = false).padding(horizontal = 12.dp), state = listState) {
            items(vm.playlists, key = { it.id }) { p ->
                ReorderableItem(rs, key = p.id) { dragging ->
                    var menu by remember { mutableStateOf(false) }
                    Row(
                        Modifier.fillMaxWidth()
                            .background(if (dragging) Color(0x55FFFFFF) else Color.Transparent)
                            .longPressDraggableHandle()
                            .clickable { onOpenPlaylist(p.id) }
                            .padding(start = 16.dp, top = 4.dp, bottom = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (p.pinned) { Icon(Ic.Pin, null, tint = W, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(6.dp)) }
                        Column(Modifier.weight(1f)) {
                            Text(p.name, color = W, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text("${p.songIds.size} lagu", color = W70, fontSize = 12.sp)
                        }
                        Box {
                            IconButton({ menu = true }) { Icon(Ic.More, "Menu", tint = W) }
                            DropdownMenu(menu, { menu = false }) {
                                DropdownMenuItem({ Text(if (p.pinned) "Lepas pin" else "Sematkan di atas") },
                                    { vm.togglePin(p.id); menu = false })
                                DropdownMenuItem({ Text("Ganti nama") }, { dlg = Dlg.Rename(p); menu = false })
                                DropdownMenuItem({ Text("Hapus") }, { dlg = Dlg.Delete(p); menu = false })
                            }
                        }
                    }
                }
            }
        }
    }
    PlaylistDialogs(vm, dlg) { dlg = null }
}

@Composable
fun PlaylistDetail(vm: MainViewModel, onBack: () -> Unit) {
    val pl = vm.playlists.firstOrNull { it.id == vm.openPlaylist }
    if (pl == null) { LaunchedEffect(Unit) { onBack() }; return }
    val byId = remember(vm.songs) { vm.songs.associateBy { it.id } }
    val favs = vm.favorites
    val list = pl.songIds.mapNotNull { byId[it] }.sortedByDescending { it.id in favs }
    var adding by remember { mutableStateOf(false) }

    val listState = rememberLazyListState()
    val rs = rememberReorderableLazyListState(listState) { from, to ->
        val fk = from.key as Long; val tk = to.key as Long
        if ((fk in vm.favorites) == (tk in vm.favorites)) vm.moveSong(pl.id, fk, tk)
    }
    Column(Modifier.fillMaxSize().systemBarsPadding().padding(12.dp)) {
        Row(Modifier.fillMaxWidth().height(56.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onBack) { Icon(Ic.Back, null, tint = W) }
            Column(Modifier.weight(1f)) {
                Text(pl.name, color = W, fontSize = 22.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text("${list.size} lagu • tekan lama 0,5 detik lalu geser", color = W70, fontSize = 12.sp)
            }
            TextButton({ adding = true }) { Text("+ Lagu", color = W) }
        }
        Box(Modifier.weight(1f).fillMaxWidth().glass(20.dp)) {
            if (list.isEmpty()) {
                Text("Playlist kosong. Tekan \"+ Lagu\" untuk menambah.", Modifier.align(Alignment.Center), color = W70)
            }
            LongPress1s {
                LazyColumn(
                    Modifier.fillMaxSize(), state = listState,
                    contentPadding = PaddingValues(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(list, key = { it.id }) { s ->
                        ReorderableItem(rs, key = s.id) { dragging ->
                            SongCard(
                                s, Modifier.longPressDraggableHandle(),
                                selected = vm.current?.id == s.id,
                                bg = if (dragging) Color(0x66FFFFFF) else Color.Transparent,
                                onClick = { vm.play(s, list) }
                            ) {
                                val fav = s.id in vm.favorites
                                IconButton({ vm.toggleFavorite(s.id) }) {
                                    Icon(if (fav) Ic.Heart else Ic.HeartOutline, if (fav) "Hapus favorit" else "Favorit",
                                        tint = if (fav) Color(0xFFFF4D6D) else W70)
                                }
                                IconButton({ vm.removeSong(pl.id, s.id) }) { Icon(Ic.Close, "Hapus", tint = W70) }
                            }
                        }
                    }
                }
            }
        }
    }
    if (adding) {
        val chosen = remember { mutableStateListOf<Long>() }
        var searchQuery by remember { mutableStateOf("") }
        val allCandidates = vm.songs.filter { it.id !in pl.songIds }
        val candidates = if (searchQuery.isBlank()) allCandidates
        else allCandidates.filter { it.title.contains(searchQuery, ignoreCase = true) }
        AlertDialog(
            onDismissRequest = { adding = false },
            containerColor = Color(0xFF0B1F3A),
            title = { Text("Tambah lagu", color = W) },
            text = {
              Column {
                OutlinedTextField(
                    value = searchQuery, onValueChange = { searchQuery = it },
                    modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                    singleLine = true,
                    placeholder = { Text("Cari lagu", color = W70) },
                    leadingIcon = { Icon(Ic.Search, "Cari", tint = W70) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = W, unfocusedTextColor = W, cursorColor = W,
                        focusedBorderColor = W70, unfocusedBorderColor = Color(0x44FFFFFF)
                    )
                )
                if (allCandidates.isEmpty()) Text("Semua lagu sudah ada di playlist.", color = W70)
                else if (candidates.isEmpty()) Text("Lagu tidak ditemukan.", color = W70)
                else LazyColumn(Modifier.heightIn(max = 360.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(candidates, key = { it.id }) { s ->
                        val on = s.id in chosen
                        SongCard(s, selected = on, bg = if (on) Color(0x4DFFFFFF) else Color.Transparent,
                            onClick = { if (on) chosen.remove(s.id) else chosen.add(s.id) }) {
                            if (on) Icon(Ic.Check, null, tint = W, modifier = Modifier.size(22.dp))
                        }
                    }
                }
              }
            },
            confirmButton = {
                TextButton({ vm.addSongs(pl.id, chosen.toList()); adding = false }, enabled = chosen.isNotEmpty()) {
                    Text(if (chosen.isEmpty()) "Tambah" else "Tambah (${chosen.size})")
                }
            },
            dismissButton = { TextButton({ adding = false }) { Text("Batal") } }
        )
    }
}
