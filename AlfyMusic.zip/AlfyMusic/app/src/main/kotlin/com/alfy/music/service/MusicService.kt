package com.alfy.music.service

import android.app.PendingIntent
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaMetadataRetriever
import android.media.audiofx.Equalizer
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.Size
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.Player
import androidx.media3.common.util.BitmapLoader
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.DefaultMediaNotificationProvider
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import com.alfy.music.R
import com.alfy.music.data.Prefs
import com.alfy.music.ui.MainActivity
import com.google.common.util.concurrent.ListenableFuture
import com.google.common.util.concurrent.SettableFuture
import java.util.concurrent.Executors

/** Pengelola Equalizer kustom (android.media.audiofx.Equalizer) — dipakai service & UI. */
object EqManager {
    private var eq: Equalizer? = null
    private val defFreqs = listOf(60, 230, 910, 3600, 14000)

    class Info(val bands: Int, val minMb: Int, val maxMb: Int, val freqsHz: List<Int>)

    fun info(): Info {
        val e = eq
        return if (e != null) try {
            val r = e.bandLevelRange
            Info(e.numberOfBands.toInt(), r[0].toInt(), r[1].toInt(),
                (0 until e.numberOfBands.toInt()).map { e.getCenterFreq(it.toShort()) / 1000 })
        } catch (_: Exception) { Info(5, -1500, 1500, defFreqs) }
        else Info(5, -1500, 1500, defFreqs)
    }

    fun attach(sessionId: Int, prefs: Prefs) {
        release()
        if (sessionId == 0) return
        try {
            val e = Equalizer(0, sessionId)
            eq = e
            apply(prefs)
        } catch (_: Exception) { eq = null }
    }

    fun apply(prefs: Prefs) {
        val e = eq ?: return
        try {
            val saved = prefs.eqLevels
            val r = e.bandLevelRange
            for (b in 0 until e.numberOfBands.toInt()) {
                val lv = (saved.getOrNull(b) ?: 0).coerceIn(r[0].toInt(), r[1].toInt())
                e.setBandLevel(b.toShort(), lv.toShort())
            }
            e.enabled = prefs.eqEnabled
        } catch (_: Exception) {}
    }

    fun setEnabled(prefs: Prefs, on: Boolean) {
        prefs.eqEnabled = on
        try { eq?.enabled = on } catch (_: Exception) {}
    }

    fun setLevel(prefs: Prefs, band: Int, mb: Int) {
        val n = info().bands
        val l = prefs.eqLevels.toMutableList()
        while (l.size < n) l.add(0)
        l[band] = mb
        prefs.eqLevels = l
        try { eq?.setBandLevel(band.toShort(), mb.toShort()) } catch (_: Exception) {}
    }

    fun release() {
        try { eq?.release() } catch (_: Exception) {}
        eq = null
    }
}

/** Foreground media service: notifikasi Media3 (cover, judul, prev/play/next) + fokus audio manual + simpan state. */
class MusicService : MediaSessionService() {
    private var session: MediaSession? = null
    private var player: ExoPlayer? = null
    private lateinit var prefs: Prefs
    private lateinit var am: AudioManager
    private var focusReq: AudioFocusRequest? = null
    private var resumeOnGain = false
    private var pausedByFocus = false
    private val main = Handler(Looper.getMainLooper())

    private val attrs = AudioAttributes.Builder()
        .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
        .setUsage(C.USAGE_MEDIA)
        .build()

    private val platformAttrs = android.media.AudioAttributes.Builder()
        .setContentType(android.media.AudioAttributes.CONTENT_TYPE_MUSIC)
        .setUsage(android.media.AudioAttributes.USAGE_MEDIA)
        .build()

    /**
     * Fokus manual. Jika "Hentikan saat panggilan" OFF: LOSS & LOSS_TRANSIENT DIABAIKAN (tidak pause),
     * sehingga musik tidak mati saat YouTube dibuka. Tidak ada ducking.
     */
    private val focusListener = AudioManager.OnAudioFocusChangeListener { change ->
        val p = player ?: return@OnAudioFocusChangeListener
        when (change) {
            AudioManager.AUDIOFOCUS_GAIN -> {
                p.volume = 1f
                if (resumeOnGain) { resumeOnGain = false; p.play() }
            }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> {
                // Ducking hanya jika checkbox 1 dicentang; selain itu abaikan.
                if (prefs.duckOnNotif) p.volume = 0.2f else p.volume = 1f
            }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT,
            AudioManager.AUDIOFOCUS_LOSS -> {
                // Checkbox 2 tidak dicentang: ABAIKAN total (tidak pause).
                if (!prefs.stopOnCall) return@OnAudioFocusChangeListener
                if (p.isPlaying) {
                    resumeOnGain = change == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT
                    pausedByFocus = true
                    p.pause()
                }
                if (change == AudioManager.AUDIOFOCUS_LOSS) { resumeOnGain = false; abandonFocus() }
            }
        }
    }

    // Checkbox 4: cabut headset / output terputus
    private val noisyReceiver = object : android.content.BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            if (i?.action == AudioManager.ACTION_AUDIO_BECOMING_NOISY && prefs.pauseOnDisconnect) player?.pause()
        }
    }

    // Checkbox 3: volume sistem nol
    private val volumeObserver = object : android.database.ContentObserver(main) {
        override fun onChange(selfChange: Boolean) {
            if (!prefs.pauseOnZeroVolume) return
            val p = player ?: return
            if (am.getStreamVolume(AudioManager.STREAM_MUSIC) == 0 && p.isPlaying) p.pause()
        }
    }

    private fun requestFocus() {
        val req = focusReq ?: AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
            .setAudioAttributes(platformAttrs)
            .setWillPauseWhenDucked(false)
            .setAcceptsDelayedFocusGain(true)
            .setOnAudioFocusChangeListener(focusListener, main)
            .build().also { focusReq = it }
        am.requestAudioFocus(req) // hasil gagal pun TIDAK menghentikan musik
    }

    private fun abandonFocus() { focusReq?.let { am.abandonAudioFocusRequest(it) } }

    private val playerListener = object : Player.Listener {
        override fun onAudioSessionIdChanged(audioSessionId: Int) {
            MusicService.audioSessionId = audioSessionId
            EqManager.attach(audioSessionId, prefs)
        }

        override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) {
            if (pausedByFocus) { pausedByFocus = false; return }
            resumeOnGain = false
            if (playWhenReady) requestFocus() else abandonFocus()
        }

        override fun onEvents(player: Player, events: Player.Events) {
            if (player.mediaItemCount == 0) return
            if (events.contains(Player.EVENT_TIMELINE_CHANGED)) {
                prefs.saveQueue((0 until player.mediaItemCount).mapNotNull { player.getMediaItemAt(it).mediaId.toLongOrNull() })
            }
            saveState()
        }
    }

    private fun saveState() {
        val p = player ?: return
        if (p.mediaItemCount == 0) return
        val id = p.currentMediaItem?.mediaId?.toLongOrNull() ?: return
        prefs.saveState(id, p.currentPosition.coerceAtLeast(0), p.playWhenReady, p.repeatMode, p.shuffleModeEnabled)
    }

    private val ticker = object : Runnable {
        override fun run() { if (player?.isPlaying == true) saveState(); main.postDelayed(this, 2000) }
    }

    /** Memuat cover dari URI lagu (Android 10+: loadThumbnail) agar tampil di notifikasi seperti referensi. */
    private inner class ArtBitmapLoader : BitmapLoader {
        private val exec = Executors.newSingleThreadExecutor()
        override fun supportsMimeType(mimeType: String) = mimeType.startsWith("image/")
        override fun decodeBitmap(data: ByteArray): ListenableFuture<Bitmap> {
            val f = SettableFuture.create<Bitmap>()
            exec.execute {
                val b = BitmapFactory.decodeByteArray(data, 0, data.size)
                if (b != null) f.set(b) else f.setException(IllegalStateException("decode"))
            }
            return f
        }
        override fun loadBitmap(uri: Uri): ListenableFuture<Bitmap> {
            val f = SettableFuture.create<Bitmap>()
            exec.execute {
                val b = try {
                    if (Build.VERSION.SDK_INT >= 29) {
                        contentResolver.loadThumbnail(uri, Size(512, 512), null)
                    } else {
                        val r = MediaMetadataRetriever()
                        try {
                            r.setDataSource(this@MusicService, uri)
                            r.embeddedPicture?.let { BitmapFactory.decodeByteArray(it, 0, it.size) }
                        } finally { r.release() }
                    }
                } catch (e: Exception) { null }
                if (b != null) f.set(b) else f.setException(IllegalStateException("no art"))
            }
            return f
        }
    }

    companion object {
        @Volatile var audioSessionId: Int = 0
    }

    override fun onCreate() {
        super.onCreate()
        prefs = Prefs(this)
        am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val player = ExoPlayer.Builder(this)
            .setAudioAttributes(attrs, false) // handleAudioFocus = false; fokus diatur manual
            .setHandleAudioBecomingNoisy(false)
            .setWakeMode(C.WAKE_MODE_LOCAL)
            .build()
        this.player = player
        player.addListener(playerListener)
        audioSessionId = player.audioSessionId
        EqManager.attach(player.audioSessionId, prefs)

        val open = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        session = MediaSession.Builder(this, player)
            .setSessionActivity(open)
            .setBitmapLoader(ArtBitmapLoader())
            .build()
        setMediaNotificationProvider(DefaultMediaNotificationProvider.Builder(this).build().also {
            it.setSmallIcon(R.drawable.ic_notif)
        })
        registerReceiver(noisyReceiver, android.content.IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY))
        contentResolver.registerContentObserver(android.provider.Settings.System.CONTENT_URI, true, volumeObserver)
        main.postDelayed(ticker, 2000)
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo) = session

    override fun onTaskRemoved(rootIntent: Intent?) {
        saveState()
        val p = session?.player
        if (p == null || !p.playWhenReady || p.mediaItemCount == 0) stopSelf()
    }

    override fun onDestroy() {
        main.removeCallbacks(ticker)
        saveState()
        try { unregisterReceiver(noisyReceiver) } catch (_: Exception) {}
        contentResolver.unregisterContentObserver(volumeObserver)
        abandonFocus()
        EqManager.release()
        val p = player
        player = null
        try { p?.removeListener(playerListener) } catch (_: Exception) {}
        session?.run { try { player.release() } catch (_: Exception) {}; release() }
        session = null
        try { p?.release() } catch (_: Exception) {}
        com.alfy.music.data.ArtLoader.trim()
        super.onDestroy()
    }
}
