package com.alfy.music.service

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import com.alfy.music.data.Prefs

/** Foreground media service: Media3 posts the (ongoing) notification with cover, title, prev/play/next. */
class MusicService : MediaSessionService() {
    private var session: MediaSession? = null
    private var player: ExoPlayer? = null
    private lateinit var prefs: Prefs
    private lateinit var am: AudioManager
    private var focusReq: AudioFocusRequest? = null
    private var resumeOnGain = false
    private var pausedByFocus = false

    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key == Prefs.KEY_ANTI_MATI) applyAntiMati()
    }

    private val attrs = AudioAttributes.Builder()
        .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
        .setUsage(C.USAGE_MEDIA)
        .build()

    private val platformAttrs = android.media.AudioAttributes.Builder()
        .setContentType(android.media.AudioAttributes.CONTENT_TYPE_MUSIC)
        .setUsage(android.media.AudioAttributes.USAGE_MEDIA)
        .build()

    /** Fokus manual: TIDAK ada penurunan volume (ducking). Hanya jeda untuk panggilan/LOSS. */
    private val focusListener = AudioManager.OnAudioFocusChangeListener { change ->
        val p = player ?: return@OnAudioFocusChangeListener
        when (change) {
            AudioManager.AUDIOFOCUS_GAIN -> {
                p.volume = 1f
                if (resumeOnGain) { resumeOnGain = false; p.play() }
            }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> {
                if (p.isPlaying) { resumeOnGain = true; pausedByFocus = true; p.pause() }
            }
            AudioManager.AUDIOFOCUS_LOSS -> {
                resumeOnGain = false
                if (p.isPlaying) { pausedByFocus = true; p.pause() }
                abandonFocus()
            }
            else -> p.volume = 1f // CAN_DUCK: abaikan, volume tetap penuh
        }
    }

    private val playerListener = object : Player.Listener {
        override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) {
            if (!prefs.antiMati) return
            if (pausedByFocus) { pausedByFocus = false; return }
            if (playWhenReady) {
                resumeOnGain = false
                if (!requestFocus()) player?.pause()
            } else {
                resumeOnGain = false
                abandonFocus()
            }
        }
    }

    private fun requestFocus(): Boolean {
        val req = focusReq ?: AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
            .setAudioAttributes(platformAttrs)
            .setWillPauseWhenDucked(false)
            .setAcceptsDelayedFocusGain(true)
            .setOnAudioFocusChangeListener(focusListener, Handler(Looper.getMainLooper()))
            .build().also { focusReq = it }
        val r = am.requestAudioFocus(req)
        return r != AudioManager.AUDIOFOCUS_REQUEST_FAILED
    }

    private fun abandonFocus() {
        focusReq?.let { am.abandonAudioFocusRequest(it) }
    }

    /** ON: fokus manual (jeda saat telepon, lanjut otomatis) + wake lock layar mati. */
    private fun applyAntiMati() {
        val p = player ?: return
        val on = prefs.antiMati
        p.setWakeMode(if (on) C.WAKE_MODE_LOCAL else C.WAKE_MODE_NONE)
        if (on) { if (p.playWhenReady) requestFocus() } else { resumeOnGain = false; abandonFocus() }
    }

    companion object {
        @Volatile var audioSessionId: Int = 0
    }

    override fun onCreate() {
        super.onCreate()
        prefs = Prefs(this)
        am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val player = ExoPlayer.Builder(this)
            .setAudioAttributes(attrs, false) // handleAudioFocus = false; fokus diatur manual
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(if (prefs.antiMati) C.WAKE_MODE_LOCAL else C.WAKE_MODE_NONE)
            .build()
        this.player = player
        player.addListener(playerListener)
        audioSessionId = player.audioSessionId
        prefs.listen(prefListener)
        session = MediaSession.Builder(this, player).build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo) = session

    override fun onTaskRemoved(rootIntent: Intent?) {
        val p = session?.player
        if (p == null || !p.playWhenReady || p.mediaItemCount == 0) stopSelf()
    }

    override fun onDestroy() {
        prefs.unlisten(prefListener)
        abandonFocus()
        player = null
        session?.run { player.release(); release() }
        session = null
        super.onDestroy()
    }
}
