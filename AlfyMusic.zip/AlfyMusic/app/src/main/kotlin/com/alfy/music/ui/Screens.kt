package com.alfy.music.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.IntOffset
import kotlinx.coroutines.delay
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.Player

private val W = Color.White
private val W70 = Color(0xB3FFFFFF)

@Composable
fun Home(vm: MainViewModel, onMenu: () -> Unit, onRequestPerm: () -> Unit) {
    var menu by remember { mutableStateOf(false) }
    var showRename by remember { mutableStateOf(false) }
    var searching by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    val sub = vm.mode.label + (vm.group?.let { " • $it" } ?: "")
    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 12.dp)) {
        Box(Modifier.fillMaxWidth().height(56.dp)) {
            Row(Modifier.align(Alignment.CenterStart), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onMenu, Modifier.size(36.dp)) { Icon(Ic.Menu, "Menu", tint = W) }
                Box {
                    Row(
                        Modifier.clip(RoundedCornerShape(8.dp)).clickable { menu = true }.padding(horizontal = 2.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Koleksi", color = W, fontSize = 14.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                        Icon(Ic.Drop, null, tint = W, modifier = Modifier.size(18.dp))
                        Text(sub, color = W70, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.widthIn(max = 34.dp))
                    }
                    DropdownMenu(menu, { menu = false }) {
                        Mode.values().forEach { m ->
                            DropdownMenuItem(text = { Text(m.label) }, onClick = { vm.updateMode(m); menu = false })
                        }
                        HorizontalDivider()
                        Text("Urutkan", fontSize = 12.sp, fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp))
                        SortOrder.values().forEach { o ->
                            DropdownMenuItem(
                                text = { Text(o.label, fontWeight = if (vm.sortOrder == o) FontWeight.Bold else FontWeight.Normal) },
                                trailingIcon = { if (vm.sortOrder == o) Text("✓") },
                                onClick = { vm.updateSort(o); menu = false }
                            )
                        }
                    }
                }
            }
            AlfyLogo(Modifier.align(Alignment.Center)) { showRename = true }
            IconButton({ searching = !searching; if (!searching) query = "" },
                Modifier.align(Alignment.CenterEnd).size(40.dp)) { Icon(Ic.Search, "Cari", tint = W) }
        }
        if (searching) {
            OutlinedTextField(
                query, { query = it }, singleLine = true, placeholder = { Text("Cari lagu...") },
                modifier = Modifier.fillMaxWidth().padding(bottom = 6.dp)
            )
        }
        if (showRename) RenameAppDialog { showRename = false }
        PlayerCard(vm)
        Spacer(Modifier.height(10.dp))
        Box(Modifier.weight(1f).fillMaxWidth().glass(20.dp)) { SongList(vm, query, onRequestPerm) }
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun PlayerCard(vm: MainViewModel) {
    val s = vm.current
    var drag by remember { mutableStateOf<Float?>(null) }
    val dur = vm.duration.coerceAtLeast(1L)
    Column(
        Modifier.fillMaxWidth().glass(28.dp).padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(Modifier.size(150.dp)) {
            Art(s, Modifier.fillMaxSize(), 18.dp)
            RainbowBorderOverlay(Modifier.matchParentSize(), 18.dp)
        }
        Spacer(Modifier.height(10.dp))
        MarqueeTitle(s?.title ?: "Pilih lagu", vm.playing)
        Text(s?.artist ?: "-", color = W70, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Slider(
            value = drag ?: (vm.position.toFloat() / dur).coerceIn(0f, 1f),
            onValueChange = { drag = it },
            onValueChangeFinished = { drag?.let { vm.seekTo((it * dur).toLong()) }; drag = null },
            colors = SliderDefaults.colors(
                thumbColor = W, activeTrackColor = W, inactiveTrackColor = Color(0x4DFFFFFF)
            )
        )
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(fmt(vm.position), color = W70, fontSize = 11.sp)
            Text(fmt(vm.duration), color = W70, fontSize = 11.sp)
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
            IconButton(vm::toggleShuffle) {
                Icon(Ic.Shuffle, "Shuffle", tint = if (vm.shuffle) W else Color(0x80FFFFFF))
            }
            IconButton(vm::prev) { Icon(Ic.Prev, "Prev", tint = W) }
            Box(
                Modifier.size(64.dp, 44.dp).clip(RoundedCornerShape(22.dp)).glass(22.dp).clickable { vm.toggle() },
                Alignment.Center
            ) { Icon(if (vm.playing) Ic.Pause else Ic.Play, "Play/Pause", tint = W, modifier = Modifier.size(28.dp)) }
            IconButton(vm::next) { Icon(Ic.Next, "Next", tint = W) }
            IconButton(vm::cycleRepeat) {
                Icon(
                    if (vm.repeat == Player.REPEAT_MODE_ONE) Ic.RepeatOne else Ic.Repeat, "Repeat",
                    tint = if (vm.repeat == Player.REPEAT_MODE_OFF) Color(0x80FFFFFF) else W
                )
            }
        }
    }
}

@Composable
private fun SongList(vm: MainViewModel, query: String, onRequestPerm: () -> Unit) {
    if (vm.songs.isEmpty()) {
        Column(Modifier.fillMaxSize(), Arrangement.Center, Alignment.CenterHorizontally) {
            Text("Belum ada lagu / izin belum diberikan", color = W70)
            TextButton(onRequestPerm) { Text("Beri izin & muat ulang", color = W) }
        }
        return
    }
    if (vm.mode != Mode.LAGU && vm.group == null) {
        val groups = vm.groups
        LazyColumn(Modifier.fillMaxSize()) {
            items(groups, key = { it.first }) { (name, n) ->
                Row(Modifier.fillMaxWidth().clickable { vm.group = name }.padding(16.dp, 12.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Text(name, color = W, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text("$n lagu", color = W70, fontSize = 12.sp)
                }
            }
        }
        return
    }
    val q = query.trim()
    val list = if (q.isEmpty()) vm.shown else vm.shown.filter { it.title.contains(q, true) || it.artist.contains(q, true) }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        items(list, key = { it.id }) { s ->
            SongCard(s, selected = vm.current?.id == s.id, onClick = { vm.play(s) })
        }
    }
}

private fun Modifier.background0(on: Boolean) =
    if (on) this.background(Color(0x33FFFFFF)) else this

@Composable
fun SimpleScreen(title: String, onBack: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize().systemBarsPadding().padding(12.dp)) {
        Row(Modifier.fillMaxWidth().height(56.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onBack) { Icon(Ic.Back, null, tint = W) }
            Text(title, color = W, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
        Column(Modifier.fillMaxWidth().glass(20.dp).padding(16.dp), content = content)
    }
}

@Composable
private fun RainbowBorderOverlay(modifier: Modifier, corner: androidx.compose.ui.unit.Dp) {
    val colors = remember {
        listOf(Color(0xFFFF0000), Color(0xFFFFA500), Color(0xFFFFFF00), Color(0xFF00FF00),
            Color(0xFF00BFFF), Color(0xFF8A2BE2), Color(0xFFFF0000))
    }
    val phase by rememberInfiniteTransition(label = "artBorder").animateFloat(
        0f, 600f, infiniteRepeatable(tween(3000, easing = LinearEasing), RepeatMode.Restart), label = "p"
    )
    val brush = Brush.linearGradient(
        colors, start = Offset(phase, phase), end = Offset(phase + 600f, phase + 600f), tileMode = TileMode.Repeated
    )
    Box(modifier.border(3.dp, brush, RoundedCornerShape(corner)))
}

/** Judul berjalan ke kanan, hanya saat [playing]; saat pause kembali diam di awal teks. */
@Composable
private fun MarqueeTitle(title: String, playing: Boolean) {
    var boxW by remember { mutableIntStateOf(0) }
    var textW by remember { mutableIntStateOf(0) }
    val overflow = (textW - boxW).coerceAtLeast(0)
    val off = remember { Animatable(0f) }
    LaunchedEffect(playing, overflow, title) {
        if (!playing || overflow <= 0) { off.animateTo(0f, tween(250)); return@LaunchedEffect }
        while (true) {
            off.snapTo(-overflow.toFloat())
            off.animateTo(0f, tween((overflow * 18).coerceAtLeast(1500), easing = LinearEasing))
            delay(700)
        }
    }
    Box(
        Modifier.fillMaxWidth().clipToBounds().onSizeChanged { boxW = it.width },
        contentAlignment = if (overflow > 0) Alignment.CenterStart else Alignment.Center
    ) {
        Text(
            title, color = W, fontSize = 18.sp, fontWeight = FontWeight.SemiBold,
            maxLines = 1, softWrap = false, textAlign = TextAlign.Center,
            modifier = Modifier.wrapContentWidth(Alignment.Start, unbounded = true)
                .onSizeChanged { textW = it.width }
                .offset { IntOffset(if (overflow > 0) off.value.toInt() else 0, 0) }
        )
    }
}
