package com.alfy.music.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.launch

enum class Screen { HOME, SETTINGS, DETAIL }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Color(0xFFFFB27A))) { App() }
        }
    }
}

@Composable
private fun App(vm: MainViewModel = viewModel()) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val drawer = rememberDrawerState(DrawerValue.Closed)
    var screen by remember { mutableStateOf(Screen.HOME) }

    val audioPerm = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
    else Manifest.permission.READ_EXTERNAL_STORAGE
    val perms = if (Build.VERSION.SDK_INT >= 33) arrayOf(audioPerm, Manifest.permission.POST_NOTIFICATIONS)
    else arrayOf(audioPerm)
    fun granted() = ContextCompat.checkSelfPermission(ctx, audioPerm) == PackageManager.PERMISSION_GRANTED

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        if (granted()) vm.load()
    }
    val bgPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let {
            try { ctx.contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            vm.setBg(it)
        }
    }
    LaunchedEffect(Unit) { if (granted()) vm.load() else permLauncher.launch(perms) }

    BackHandler(screen != Screen.HOME || vm.group != null) {
        if (screen != Screen.HOME) screen = Screen.HOME else vm.group = null
    }

    Box(Modifier.fillMaxSize()) {
        Background(vm.bgUri)
        ModalNavigationDrawer(
            drawerState = drawer,
            drawerContent = {
                ModalDrawerSheet(drawerContainerColor = Color(0xE60B1F3A)) {
                    DrawerContent(
                        vm,
                        onSettings = { scope.launch { drawer.close() }; screen = Screen.SETTINGS },
                        onBackground = { scope.launch { drawer.close() }; bgPicker.launch(arrayOf("image/*")) },
                        onOpenPlaylist = { id -> vm.openPlaylist = id; screen = Screen.DETAIL; scope.launch { drawer.close() } }
                    )
                }
            }
        ) {
            when (screen) {
                Screen.HOME -> Home(vm, { scope.launch { drawer.open() } }, { permLauncher.launch(perms) })
                Screen.SETTINGS -> SettingsScreen(vm) { screen = Screen.HOME }
                Screen.DETAIL -> PlaylistDetail(vm) { screen = Screen.HOME }
            }
        }
    }
}
