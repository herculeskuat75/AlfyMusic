package com.alfy.music.data

import android.content.Context
import android.net.Uri

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("alfy", Context.MODE_PRIVATE)
    var bg: Uri?
        get() = sp.getString("bg", null)?.let(Uri::parse)
        set(v) { sp.edit().putString("bg", v?.toString()).apply() }

    /** ON: jeda saat panggilan/aplikasi lain ambil fokus. OFF (default): abaikan AUDIOFOCUS_LOSS*, musik tetap jalan. */
    var stopOnCall: Boolean
        get() = sp.getBoolean(KEY_STOP_ON_CALL, false)
        set(v) { sp.edit().putBoolean(KEY_STOP_ON_CALL, v).apply() }

    /** Kecilkan volume saat ada notifikasi (ducking). Default OFF. */
    var duckOnNotif: Boolean
        get() = sp.getBoolean("duck_on_notif", false)
        set(v) { sp.edit().putBoolean("duck_on_notif", v).apply() }

    /** Hentikan pemutaran jika volume perangkat nol. Default OFF. */
    var pauseOnZeroVolume: Boolean
        get() = sp.getBoolean("pause_zero_vol", false)
        set(v) { sp.edit().putBoolean("pause_zero_vol", v).apply() }

    /** Jeda saat output audio terputus (cabut headset/BT). Default OFF. */
    var pauseOnDisconnect: Boolean
        get() = sp.getBoolean("pause_on_disconnect", false)
        set(v) { sp.edit().putBoolean("pause_on_disconnect", v).apply() }

    // ---- State pemutar terakhir
    class PlayerState(
        val songId: Long, val positionMs: Long, val wasPlaying: Boolean,
        val repeat: Int, val shuffle: Boolean, val queue: List<Long>
    )

    fun saveQueue(ids: List<Long>) { sp.edit().putString("st_queue", ids.joinToString(",")).apply() }

    fun saveState(songId: Long, positionMs: Long, playing: Boolean, repeat: Int, shuffle: Boolean) {
        sp.edit().putLong("st_song", songId).putLong("st_pos", positionMs).putBoolean("st_playing", playing)
            .putInt("st_repeat", repeat).putBoolean("st_shuffle", shuffle).apply()
    }

    fun loadState(): PlayerState? {
        val id = sp.getLong("st_song", -1L)
        if (id < 0) return null
        val q = (sp.getString("st_queue", "") ?: "").split(",").mapNotNull { it.toLongOrNull() }
        return PlayerState(id, sp.getLong("st_pos", 0L), sp.getBoolean("st_playing", false),
            sp.getInt("st_repeat", 0), sp.getBoolean("st_shuffle", false), q)
    }

    /** ID lagu favorit (ikon Love). */
    var favorites: Set<Long>
        get() = (sp.getStringSet("favorites", emptySet()) ?: emptySet()).mapNotNull { it.toLongOrNull() }.toSet()
        set(v) { sp.edit().putStringSet("favorites", v.map { it.toString() }.toSet()).apply() }

    var sortOrder: String
        get() = sp.getString("sort_order", "NAME_ASC") ?: "NAME_ASC"
        set(v) { sp.edit().putString("sort_order", v).apply() }

    var appName: String
        get() = sp.getString("app_name", "AlfyMusic") ?: "AlfyMusic"
        set(v) { sp.edit().putString("app_name", v).apply() }

    var rainbowSpeed: Float
        get() = sp.getFloat("rainbow_speed", 1f)
        set(v) { sp.edit().putFloat("rainbow_speed", v).apply() }

    // ---- Equalizer kustom
    var eqEnabled: Boolean
        get() = sp.getBoolean("eq_enabled", false)
        set(v) { sp.edit().putBoolean("eq_enabled", v).apply() }

    /** Level tiap band dalam millibel, dipisah koma. */
    var eqLevels: List<Int>
        get() = (sp.getString("eq_levels", "") ?: "").split(",").mapNotNull { it.toIntOrNull() }
        set(v) { sp.edit().putString("eq_levels", v.joinToString(",")).apply() }

    fun listen(l: android.content.SharedPreferences.OnSharedPreferenceChangeListener) = sp.registerOnSharedPreferenceChangeListener(l)
    fun unlisten(l: android.content.SharedPreferences.OnSharedPreferenceChangeListener) = sp.unregisterOnSharedPreferenceChangeListener(l)

    companion object { const val KEY_STOP_ON_CALL = "stop_on_call" }
}
