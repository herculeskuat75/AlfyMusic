package com.alfy.music.data

import android.content.Context
import android.net.Uri

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("alfy", Context.MODE_PRIVATE)
    var bg: Uri?
        get() = sp.getString("bg", null)?.let(Uri::parse)
        set(v) { sp.edit().putString("bg", v?.toString()).apply() }

    /** Anti-Mati: audio focus (jeda saat telepon, lanjut otomatis) + wake lock saat layar mati. */
    var antiMati: Boolean
        get() = sp.getBoolean(KEY_ANTI_MATI, true)
        set(v) { sp.edit().putBoolean(KEY_ANTI_MATI, v).apply() }

    fun listen(l: android.content.SharedPreferences.OnSharedPreferenceChangeListener) = sp.registerOnSharedPreferenceChangeListener(l)
    fun unlisten(l: android.content.SharedPreferences.OnSharedPreferenceChangeListener) = sp.unregisterOnSharedPreferenceChangeListener(l)

    companion object { const val KEY_ANTI_MATI = "anti_mati" }
}
