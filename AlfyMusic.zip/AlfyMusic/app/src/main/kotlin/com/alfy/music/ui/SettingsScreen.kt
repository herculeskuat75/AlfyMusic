package com.alfy.music.ui

import android.content.Context
import android.media.MediaScannerConnection
import android.os.Environment
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.alfy.music.data.Backup
import com.alfy.music.data.Prefs
import com.alfy.music.service.EqManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

private val W = Color.White
private val W70 = Color(0xB3FFFFFF)

@Composable
fun SettingsScreen(vm: MainViewModel, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { Prefs(ctx) }
    var showRename by remember { mutableStateOf(false) }
    var showEq by remember { mutableStateOf(false) }
    var duck by remember { mutableStateOf(prefs.duckOnNotif) }
    var stopOnCall by remember { mutableStateOf(prefs.stopOnCall) }
    var zeroVol by remember { mutableStateOf(prefs.pauseOnZeroVolume) }
    var disc by remember { mutableStateOf(prefs.pauseOnDisconnect) }

    val backupLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument(Backup.MIME)
    ) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        val json = Backup.toJson(vm.playlists, vm.songs, vm.favorites)
        scope.launch {
            val ok = withContext(Dispatchers.IO) { Backup.write(ctx, uri, json) }
            toast(ctx, if (ok) "Backup playlist berhasil disimpan" else "Backup gagal")
        }
    }

    val restoreLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        scope.launch {
            val json = withContext(Dispatchers.IO) { Backup.read(ctx, uri) }
            val n = if (json == null) -1 else vm.restoreBackup(json)
            toast(ctx, if (n >= 0) "Restore berhasil: $n playlist dipulihkan" else "Restore gagal: file tidak valid")
        }
    }

    SimpleScreen("Pengaturan", onBack) {
        Text("Interaksi Sistem", color = Color(0xFFFF8A50), fontSize = 16.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold, modifier = Modifier.padding(top = 4.dp, bottom = 4.dp))
        CheckRow("Kecilkan volume saat ada notifikasi", duck) { duck = it; prefs.duckOnNotif = it }
        CheckRow("Hentikan pemutaran ketika ada panggilan atau sedang memutar media", stopOnCall) { stopOnCall = it; prefs.stopOnCall = it }
        CheckRow("Hentikan pemutaran jika volume perangkat diatur ke nol", zeroVol) { zeroVol = it; prefs.pauseOnZeroVolume = it }
        CheckRow("Jeda begitu terputus dengan perangkat output audio", disc) { disc = it; prefs.pauseOnDisconnect = it }
        HorizontalDivider(color = Color(0x33FFFFFF), modifier = Modifier.padding(vertical = 6.dp))

        SettingButton("Equalizer") { showEq = true }
        if (showEq) EqualizerDialog(prefs) { showEq = false }
        SettingButton("Scan Musik Baru") {
            toast(ctx, "Memindai musik...")
            scope.launch {
                scanMedia(ctx)
                vm.load()
                toast(ctx, "Scan selesai")
            }
        }
        SettingButton("Backup Playlist") { backupLauncher.launch(Backup.defaultName()) }
        SettingButton("Restore dari File (.alfy)") { restoreLauncher.launch(arrayOf(Backup.MIME, "*/*")) }

        HorizontalDivider(color = Color(0x33FFFFFF), modifier = Modifier.padding(vertical = 6.dp))
        SettingButton("Ganti Nama Aplikasi") { showRename = true }
        Text("Kecepatan Pelangi Logo: " + "%.1f".format(LogoState.speed), color = W, fontSize = 16.sp)
        Slider(
            value = LogoState.speed, onValueChange = { LogoState.updateSpeed(it) }, valueRange = 0f..5f,
            colors = SliderDefaults.colors(thumbColor = W, activeTrackColor = W, inactiveTrackColor = Color(0x4DFFFFFF))
        )
        HorizontalDivider(color = Color(0x33FFFFFF), modifier = Modifier.padding(vertical = 6.dp))
        SettingButton("Hapus Latar Belakang") { vm.setBg(null); toast(ctx, "Latar belakang dikembalikan ke default") }
        if (showRename) RenameAppDialog { showRename = false }
        Text("AlfyMusic v0.1", color = W70, fontSize = 12.sp)
    }
}

@Composable
private fun CheckRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable { onChange(!checked) }.padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Checkbox(checked = checked, onCheckedChange = onChange)
        Spacer(Modifier.width(12.dp))
        Text(label, color = W, fontSize = 16.sp, modifier = Modifier.weight(1f))
    }
}

@Composable
private fun SettingButton(label: String, onClick: () -> Unit) {
    TextButton(onClick, Modifier.fillMaxWidth()) {
        Text(label, color = W, fontSize = 16.sp, modifier = Modifier.fillMaxWidth())
    }
}

private fun toast(ctx: Context, msg: String) = Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show()

@Composable
private fun EqualizerDialog(prefs: Prefs, onDismiss: () -> Unit) {
    val info = remember { EqManager.info() }
    var enabled by remember { mutableStateOf(prefs.eqEnabled) }
    val levels = remember {
        val saved = prefs.eqLevels
        mutableStateListOf<Int>().also { l ->
            for (b in 0 until info.bands) l.add((saved.getOrNull(b) ?: 0).coerceIn(info.minMb, info.maxMb))
        }
    }
    fun label(hz: Int) = if (hz >= 1000) "%.1f kHz".format(hz / 1000f).replace(".0 ", " ") else "$hz Hz"

    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = onDismiss) { Text("Tutup") } },
        title = { Text("Equalizer") },
        text = {
            Column {
                Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("Aktifkan Equalizer", fontSize = 18.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold, modifier = Modifier.weight(1f))
                    Switch(checked = enabled, onCheckedChange = { enabled = it; EqManager.setEnabled(prefs, it) })
                }
                for (b in 0 until info.bands) {
                    Text(label(info.freqsHz.getOrElse(b) { 0 }) + "  (" + "%+.1f".format(levels[b] / 100f) + " dB)", fontSize = 14.sp)
                    Slider(
                        value = levels[b].toFloat(),
                        onValueChange = { v -> levels[b] = v.toInt(); EqManager.setLevel(prefs, b, v.toInt()) },
                        valueRange = info.minMb.toFloat()..info.maxMb.toFloat(),
                        enabled = enabled
                    )
                }
            }
        }
    )
}

/** Picu ulang scan MediaStore untuk folder musik umum, lalu tunggu selesai. */
private suspend fun scanMedia(ctx: Context) = withContext(Dispatchers.IO) {
    val exts = setOf("mp3", "m4a", "aac", "flac", "wav", "ogg", "opus", "wma", "amr")
    val files = ArrayList<String>()
    fun walk(f: File, depth: Int) {
        if (depth > 6) return
        f.listFiles()?.forEach {
            if (it.isDirectory) { if (!it.name.startsWith(".")) walk(it, depth + 1) }
            else if (it.extension.lowercase() in exts) files += it.absolutePath
        }
    }
    listOf(Environment.DIRECTORY_MUSIC, Environment.DIRECTORY_DOWNLOADS, Environment.DIRECTORY_PODCASTS)
        .forEach { walk(Environment.getExternalStoragePublicDirectory(it), 0) }
    if (files.isEmpty()) return@withContext
    val latch = java.util.concurrent.CountDownLatch(files.size)
    MediaScannerConnection.scanFile(ctx.applicationContext, files.toTypedArray(), null) { _, _ -> latch.countDown() }
    latch.await(20, java.util.concurrent.TimeUnit.SECONDS)
}
