package com.alfy.music.ui

import android.content.Context
import android.content.Intent
import android.media.MediaScannerConnection
import android.media.audiofx.AudioEffect
import android.os.Environment
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.alfy.music.data.Backup
import com.alfy.music.data.Prefs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

private val W = Color.White
private val W70 = Color(0xB3FFFFFF)

@Composable
fun SettingsScreen(vm: MainViewModel, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { Prefs(ctx) }
    var antiMati by remember { mutableStateOf(prefs.antiMati) }

    val backupLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument(Backup.MIME)
    ) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        val json = Backup.toJson(vm.playlists, vm.songs)
        scope.launch {
            val ok = withContext(Dispatchers.IO) { Backup.write(ctx, uri, json) }
            toast(ctx, if (ok) "Backup playlist berhasil disimpan" else "Backup gagal")
        }
    }

    SimpleScreen("Pengaturan", onBack) {
        Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Anti-Mati (Audio Focus)", color = W, fontSize = 16.sp)
                Text("Musik tetap jalan saat layar mati; jeda saat ada panggilan lalu lanjut lagi.", color = W70, fontSize = 12.sp)
            }
            Switch(checked = antiMati, onCheckedChange = { antiMati = it; prefs.antiMati = it })
        }
        HorizontalDivider(color = Color(0x33FFFFFF), modifier = Modifier.padding(vertical = 6.dp))

        SettingButton("Equalizer") { openEqualizer(ctx) }
        SettingButton("Scan Musik Baru") {
            toast(ctx, "Memindai musik...")
            scope.launch {
                scanMedia(ctx)
                vm.load()
                toast(ctx, "Scan selesai")
            }
        }
        SettingButton("Backup Playlist") { backupLauncher.launch(Backup.defaultName()) }

        HorizontalDivider(color = Color(0x33FFFFFF), modifier = Modifier.padding(vertical = 6.dp))
        TextButton({ vm.setBg(null) }) { Text("Reset latar belakang", color = W) }
        Text("AlfyMusic v0.1", color = W70, fontSize = 12.sp)
    }
}

@Composable
private fun SettingButton(label: String, onClick: () -> Unit) {
    TextButton(onClick, Modifier.fillMaxWidth()) {
        Text(label, color = W, fontSize = 16.sp, modifier = Modifier.fillMaxWidth())
    }
}

private fun toast(ctx: Context, msg: String) = Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show()

private fun openEqualizer(ctx: Context) {
    val sessionId = com.alfy.music.service.MusicService.audioSessionId
    val i = Intent(AudioEffect.ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION).apply {
        putExtra(AudioEffect.EXTRA_AUDIO_SESSION, sessionId)
        putExtra(AudioEffect.EXTRA_PACKAGE_NAME, ctx.packageName)
        putExtra(AudioEffect.EXTRA_CONTENT_TYPE, AudioEffect.CONTENT_TYPE_MUSIC)
    }
    try {
        if (i.resolveActivity(ctx.packageManager) != null) ctx.startActivity(i)
        else toast(ctx, "Equalizer bawaan tidak tersedia di perangkat ini")
    } catch (_: Exception) { toast(ctx, "Equalizer bawaan tidak tersedia di perangkat ini") }
}

/** Picu ulang scan MediaStore untuk folder musik umum, lalu tunggu selesai. */
private suspend fun scanMedia(ctx: Context) = withContext(Dispatchers.IO) {
    val exts = setOf("mp3", "m4a", "aac", "flac", "wav", "ogg", "opus", "wma", "amr")
    val files = ArrayList<String>()
    fun walk(f: File, depth: Int) {
        if (depth > 6) return
        f.listFiles()?.forEach {
            if (it.isDirectory) { if (!it.name.startsWith(".")) walk(it, depth + 1) }
            else if (it.extension.lowercase() in exts) files += it.absolutePath
        }
    }
    listOf(Environment.DIRECTORY_MUSIC, Environment.DIRECTORY_DOWNLOADS, Environment.DIRECTORY_PODCASTS)
        .forEach { walk(Environment.getExternalStoragePublicDirectory(it), 0) }
    if (files.isEmpty()) return@withContext
    val latch = java.util.concurrent.CountDownLatch(files.size)
    MediaScannerConnection.scanFile(ctx.applicationContext, files.toTypedArray(), null) { _, _ -> latch.countDown() }
    latch.await(20, java.util.concurrent.TimeUnit.SECONDS)
}
