package com.alfy.music.data

import android.content.Context
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Backup playlist ke file .alfy (JSON teks). */
object Backup {
    const val MIME = "application/octet-stream"

    fun defaultName(): String = SimpleDateFormat("dd_MM_yyyy", Locale.US).format(Date()) + "_music.alfy"

    fun toJson(playlists: List<Playlist>, songs: List<Song>, favorites: Set<Long> = emptySet()): String {
        val byId = songs.associateBy { it.id }
        val arr = JSONArray()
        playlists.forEach { p ->
            val items = JSONArray()
            p.songIds.forEach { id ->
                val s = byId[id]
                items.put(JSONObject().put("id", id).put("title", s?.title ?: "").put("artist", s?.artist ?: ""))
            }
            arr.put(
                JSONObject().put("id", p.id).put("name", p.name).put("pinned", p.pinned)
                    .put("auto", p.auto).put("key", p.key)
                    .put("songs", JSONArray(p.songIds)).put("items", items)
            )
        }
        return JSONObject().put("app", "AlfyMusic").put("version", 1)
            .put("created", System.currentTimeMillis()).put("playlists", arr)
            .put("favorites", JSONArray(favorites.toList())).toString(2)
    }

    class Restored(val playlists: List<Playlist>, val favorites: Set<Long>, val count: Int)

    /** Baca isi file .alfy. Return null jika gagal. Panggil dari thread IO. */
    fun read(ctx: Context, uri: Uri): String? = try {
        ctx.contentResolver.openInputStream(uri)?.use { it.readBytes().toString(Charsets.UTF_8) }
    } catch (_: Exception) { null }

    /**
     * Gabungkan playlist dari JSON ke daftar yang ada: playlist bernama sama (atau auto-key sama) ditimpa,
     * selain itu ditambahkan. ID lagu dicocokkan ke perangkat via id, lalu judul+artis. Null jika JSON tidak valid.
     */
    fun restore(json: String, existing: List<Playlist>, songs: List<Song>): Restored? = try {
        val root = JSONObject(json)
        val arr = root.getJSONArray("playlists")
        val byId = songs.associateBy { it.id }
        val byTitle = songs.associateBy { it.title.lowercase() + "|" + it.artist.lowercase() }
        val out = existing.toMutableList()
        var nextId = (out.maxOfOrNull { it.id } ?: 0L) + 1
        var n = 0
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val name = o.getString("name")
            val key = o.optString("key")
            val auto = o.optBoolean("auto")
            val ids = o.optJSONArray("songs") ?: JSONArray()
            val items = o.optJSONArray("items")
            val resolved = LinkedHashSet<Long>()
            for (j in 0 until ids.length()) {
                val id = ids.getLong(j)
                val meta = items?.optJSONObject(j)
                val s = byId[id]?.takeIf { meta == null || meta.optString("title").isEmpty() || it.title == meta.optString("title") }
                    ?: meta?.let { byTitle[it.optString("title").lowercase() + "|" + it.optString("artist").lowercase()] }
                    ?: byId[id]
                if (s != null) resolved += s.id
            }
            val at = out.indexOfFirst { (auto && it.auto && key.isNotEmpty() && it.key == key) || it.name.equals(name, true) }
            if (at >= 0) out[at] = out[at].copy(name = name, pinned = o.optBoolean("pinned"), songIds = resolved.toList())
            else out += Playlist(nextId++, name, o.optBoolean("pinned"), auto, key, resolved.toList())
            n++
        }
        val fav = root.optJSONArray("favorites")
        val favs = if (fav == null) emptySet() else (0 until fav.length()).map { fav.getLong(it) }.toSet()
        Restored(out, favs, n)
    } catch (_: Exception) { null }

    /** Tulis ke Uri hasil CreateDocument. Return true jika sukses. Panggil dari thread IO. */
    fun write(ctx: Context, uri: Uri, json: String): Boolean = try {
        ctx.contentResolver.openOutputStream(uri, "wt")?.use { it.write(json.toByteArray(Charsets.UTF_8)) } != null
    } catch (_: Exception) { false }
}
