package com.alfy.music.data

import android.content.Context
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Backup playlist ke file .alfy (JSON teks). */
object Backup {
    const val MIME = "application/octet-stream"

    fun defaultName(): String = SimpleDateFormat("dd_MM_yyyy", Locale.US).format(Date()) + "_music.alfy"

    fun toJson(playlists: List<Playlist>, songs: List<Song>): String {
        val byId = songs.associateBy { it.id }
        val arr = JSONArray()
        playlists.forEach { p ->
            val items = JSONArray()
            p.songIds.forEach { id ->
                val s = byId[id]
                items.put(JSONObject().put("id", id).put("title", s?.title ?: "").put("artist", s?.artist ?: ""))
            }
            arr.put(
                JSONObject().put("id", p.id).put("name", p.name).put("pinned", p.pinned)
                    .put("auto", p.auto).put("key", p.key)
                    .put("songs", JSONArray(p.songIds)).put("items", items)
            )
        }
        return JSONObject().put("app", "AlfyMusic").put("version", 1)
            .put("created", System.currentTimeMillis()).put("playlists", arr).toString(2)
    }

    /** Tulis ke Uri hasil CreateDocument. Return true jika sukses. Panggil dari thread IO. */
    fun write(ctx: Context, uri: Uri, json: String): Boolean = try {
        ctx.contentResolver.openOutputStream(uri, "wt")?.use { it.write(json.toByteArray(Charsets.UTF_8)) } != null
    } catch (_: Exception) { false }
}
