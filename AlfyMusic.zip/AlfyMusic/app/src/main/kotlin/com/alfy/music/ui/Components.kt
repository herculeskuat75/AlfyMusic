package com.alfy.music.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.alfy.music.data.ArtLoader
import com.alfy.music.data.Song
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Ikon vektor ringan (tanpa material-icons-extended). */
object Ic {
    private fun v(name: String, d: String) =
        ImageVector.Builder(name, 24.dp, 24.dp, 24f, 24f)
            .addPath(PathParser().parsePathString(d).toNodes(), fill = SolidColor(Color.Black)).build()

    val Play by lazy { v("play", "M8,5v14l11,-7z") }
    val Pause by lazy { v("pause", "M6,19h4V5H6v14zM14,5v14h4V5h-4z") }
    val Next by lazy { v("next", "M6,18l8.5,-6L6,6v12zM16,6v12h2V6h-2z") }
    val Prev by lazy { v("prev", "M6,6h2v12H6zM9.5,12l8.5,6V6z") }
    val Shuffle by lazy { v("shuffle", "M10.59,9.17L5.41,4 4,5.41l5.17,5.17 1.42,-1.41zM14.5,4l2.04,2.04L4,18.59 5.41,20 17.96,7.46 20,9.5V4h-5.5zM14.83,13.41l-1.41,1.41 3.13,3.13L14.5,20H20v-5.5l-2.04,2.04 -3.13,-3.13z") }
    val Repeat by lazy { v("repeat", "M7,7h10v3l4,-4 -4,-4v3H5v6h2V7zM17,17H7v-3l-4,4 4,4v-3h12v-6h-2v4z") }
    val RepeatOne by lazy { v("repeat1", "M7,7h10v3l4,-4 -4,-4v3H5v6h2V7zM17,17H7v-3l-4,4 4,4v-3h12v-6h-2v4zM13,15h-1v-4h-1v-1h2v5z") }
    val Menu by lazy { v("menu", "M3,18h18v-2H3v2zM3,13h18v-2H3v2zM3,6v2h18V6H3z") }
    val Drop by lazy { v("drop", "M7,10l5,5 5,-5z") }
    val Pin by lazy { v("pin", "M16,9V4l1,0c0.55,0 1,-0.45 1,-1v0c0,-0.55 -0.45,-1 -1,-1H7C6.45,2 6,2.45 6,3v0c0,0.55 0.45,1 1,1l1,0v5c0,1.66 -1.34,3 -3,3h0v2h5.97v7l1,1l1,-1v-7H19v-2h0C17.34,12 16,10.66 16,9z") }
    val More by lazy { v("more", "M12,8c1.1,0 2,-0.9 2,-2s-0.9,-2 -2,-2 -2,0.9 -2,2 0.9,2 2,2zM12,10c-1.1,0 -2,0.9 -2,2s0.9,2 2,2 2,-0.9 2,-2 -0.9,-2 -2,-2zM12,16c-1.1,0 -2,0.9 -2,2s0.9,2 2,2 2,-0.9 2,-2 -0.9,-2 -2,-2z") }
    val Back by lazy { v("back", "M20,11H7.83l5.59,-5.59L12,4l-8,8 8,8 1.41,-1.41L7.83,13H20v-2z") }
    val Close by lazy { v("close", "M19,6.41L17.59,5 12,10.59 6.41,5 5,6.41 10.59,12 5,17.59 6.41,19 12,13.41 17.59,19 19,17.59 13.41,12z") }
    val Search by lazy { v("search", "M15.5,14h-0.79l-0.28,-0.27C15.41,12.59 16,11.11 16,9.5 16,5.91 13.09,3 9.5,3S3,5.91 3,9.5 5.91,16 9.5,16c1.61,0 3.09,-0.59 4.23,-1.57l0.27,0.28v0.79l5,4.99L20.49,19l-4.99,-5zM9.5,14C7.01,14 5,11.99 5,9.5S7.01,5 9.5,5 14,7.01 14,9.5 11.99,14 9.5,14z") }
    val Note by lazy { v("note", "M12,3v10.55c-0.59,-0.34 -1.27,-0.55 -2,-0.55 -2.21,0 -4,1.79 -4,4s1.79,4 4,4 4,-1.79 4,-4V7h4V3h-6z") }
}

/** Efek kaca semi-transparan (glassmorphism ringan, tanpa blur mahal). */
fun Modifier.glass(radius: Dp = 24.dp): Modifier {
    val s = RoundedCornerShape(radius)
    return this.clip(s)
        .background(Brush.verticalGradient(listOf(Color(0x38FFFFFF), Color(0x14FFFFFF))))
        .border(1.dp, Color(0x40FFFFFF), s)
}

@Composable
fun Art(song: Song?, modifier: Modifier, radius: Dp = 12.dp) {
    val ctx = LocalContext.current
    val bmp by produceState<Bitmap?>(null, song?.id) {
        value = if (song == null) null else withContext(Dispatchers.IO) { ArtLoader.load(ctx, song) }
    }
    Box(modifier.clip(RoundedCornerShape(radius)).background(Color(0x33FFFFFF)), Alignment.Center) {
        val b = bmp
        if (b != null) {
            val img = remember(b) { b.asImageBitmap() }
            Image(img, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        } else Icon(Ic.Note, null, tint = Color(0x99FFFFFF))
    }
}

private fun decode(ctx: Context, uri: Uri, w: Int, h: Int): ImageBitmap? = try {
    val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
    var s = 1
    while (o.outWidth / (s * 2) >= w && o.outHeight / (s * 2) >= h) s *= 2
    val o2 = BitmapFactory.Options().apply { inSampleSize = s }
    ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) }?.asImageBitmap()
} catch (e: Exception) { null }

@Composable
fun Background(uri: Uri?) {
    val ctx = LocalContext.current
    val dm = ctx.resources.displayMetrics
    val bmp by produceState<ImageBitmap?>(null, uri) {
        value = uri?.let { withContext(Dispatchers.IO) { decode(ctx, it, dm.widthPixels, dm.heightPixels) } }
    }
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF062A5C), Color(0xFF0A8FD0))))) {
        bmp?.let {
            Image(it, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            Box(Modifier.fillMaxSize().background(Color(0x59000000)))
        }
    }
}

fun fmt(ms: Long): String {
    val s = (ms / 1000).toInt()
    return "%02d:%02d".format(s / 60, s % 60)
}
