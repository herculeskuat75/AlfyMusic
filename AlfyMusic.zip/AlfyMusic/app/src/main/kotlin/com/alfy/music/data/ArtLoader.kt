package com.alfy.music.data

import android.content.ContentUris
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Build
import android.util.LruCache
import android.util.Size

object ArtLoader {
    /** Naik tiap cover kustom berubah agar UI memuat ulang. */
    var version by androidx.compose.runtime.mutableIntStateOf(0)
        private set

    private fun customFile(ctx: Context, id: Long) =
        java.io.File(java.io.File(ctx.filesDir, "custom_art").apply { mkdirs() }, "$id.jpg")

    fun hasCustom(ctx: Context, song: Song) = customFile(ctx, song.id).exists()

    /** Simpan gambar dari galeri sebagai cover kustom lagu ini. */
    fun setCustom(ctx: Context, song: Song, src: android.net.Uri): Boolean = try {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        ctx.contentResolver.openInputStream(src)?.use { BitmapFactory.decodeStream(it, null, o) }
        var s = 1
        while (o.outWidth / (s * 2) >= 600 && o.outHeight / (s * 2) >= 600) s *= 2
        val bmp = ctx.contentResolver.openInputStream(src)?.use {
            BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = s })
        }
        if (bmp == null) false else {
            customFile(ctx, song.id).outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 90, it) }
            cache.evictAll(); version++; true
        }
    } catch (e: Exception) { false }

    fun removeCustom(ctx: Context, song: Song) {
        customFile(ctx, song.id).delete(); cache.evictAll(); version++
    }

    private const val PX = 320
    private const val FULL_PX = 600

    /** Cache dibatasi dalam BYTE (bukan jumlah), 1/16 heap maksimal 8 MB. */
    private val cache = object : LruCache<String, Bitmap>(
        (Runtime.getRuntime().maxMemory() / 16).coerceAtMost(8L * 1024 * 1024).toInt()
    ) {
        override fun sizeOf(key: String, value: Bitmap) = value.allocationByteCount
    }

    fun trim() { cache.evictAll() }

    private fun sampled(path: String, target: Int): Bitmap? {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(path, o)
        var s = 1
        while (o.outWidth / (s * 2) >= target && o.outHeight / (s * 2) >= target) s *= 2
        return BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = s })
    }

    /** px = 0: ukuran legacy (layar pemutar). px > 0: downsample ke ~px (thumbnail daftar lagu). */
    fun load(ctx: Context, song: Song, px: Int = 0): Bitmap? {
        val key = "${song.id}@$px"
        cache.get(key)?.let { return it }
        customFile(ctx, song.id).takeIf { it.exists() }?.let { f ->
            sampled(f.path, if (px > 0) px else FULL_PX)?.let { cache.put(key, it); return it }
        }
        val size = if (px > 0) px else PX
        val bmp = try {
            if (Build.VERSION.SDK_INT >= 29) {
                ctx.contentResolver.loadThumbnail(song.uri, Size(size, size), null)
            } else {
                val art = ContentUris.withAppendedId(
                    android.net.Uri.parse("content://media/external/audio/albumart"), song.id)
                val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                ctx.contentResolver.openInputStream(art)?.use { BitmapFactory.decodeStream(it, null, o) }
                var s = 1
                while (o.outWidth / (s * 2) >= size && o.outHeight / (s * 2) >= size) s *= 2
                ctx.contentResolver.openInputStream(art)?.use {
                    BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = s })
                }
            }
        } catch (e: Exception) { null }
        if (bmp != null) cache.put(key, bmp)
        return bmp
    }
}
