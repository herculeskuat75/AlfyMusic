package com.alfy.music.data

import android.content.ContentUris
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Build
import android.provider.MediaStore
import android.util.LruCache
import android.util.Size

object ArtLoader {
    private const val PX = 320
    private val cache = LruCache<Long, Bitmap>(16)

    fun load(ctx: Context, song: Song): Bitmap? {
        cache.get(song.id)?.let { return it }
        val bmp = try {
            if (Build.VERSION.SDK_INT >= 29) {
                ctx.contentResolver.loadThumbnail(song.uri, Size(PX, PX), null)
            } else {
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI // keep import used
                val art = ContentUris.withAppendedId(
                    android.net.Uri.parse("content://media/external/audio/albumart"), song.id)
                ctx.contentResolver.openInputStream(art)?.use { BitmapFactory.decodeStream(it) }
            }
        } catch (e: Exception) { null }
        if (bmp != null) cache.put(song.id, bmp)
        return bmp
    }
}
